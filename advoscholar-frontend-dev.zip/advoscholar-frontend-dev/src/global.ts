import "@/styles/tailwind.css";
