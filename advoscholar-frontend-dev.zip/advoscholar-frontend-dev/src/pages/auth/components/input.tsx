export const Input = () => {
  return <input className="text" />;
};
