export default function Notfound() {
  return <div>404</div>;
}
