// import Layout from "./Layout"
export default function Index() {
  return (
    <div>Hello World</div>
    // <Layout />
  );
}
